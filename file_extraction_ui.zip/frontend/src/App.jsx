import React, { useState } from "react";
import axios from "axios";

function App() {
  const [files, setFiles] = useState([]);
  const [output, setOutput] = useState("");

  const handleFileChange = (e) => {
    setFiles([...e.target.files]);
  };

  const handleUpload = async () => {
    const formData = new FormData();
    files.forEach(file => formData.append("files", file));

    await axios.post("http://localhost:5000/upload", formData);
    const res = await axios.get("http://localhost:5000/process");
    setOutput(res.data.output);
  };

  return (
    <div className="p-8 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">📄 File Extractor</h1>
      <input type="file" multiple onChange={handleFileChange} />
      <button className="mt-4 bg-blue-600 text-white px-4 py-2 rounded" onClick={handleUpload}>
        Upload & Extract
      </button>
      <pre className="mt-6 bg-gray-100 p-4 whitespace-pre-wrap">{output}</pre>
    </div>
  );
}

export default App;
