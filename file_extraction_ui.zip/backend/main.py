from flask import Flask, request, jsonify
from flask_cors import CORS
import os
from io import StringIO
import sys
from your_existing_module import fetch_and_print  # Ensure this is your actual module

app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/upload", methods=["POST"])
def upload_file():
    files = request.files.getlist("files")
    saved_files = []
    for file in files:
        save_path = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(save_path)
        saved_files.append(file.filename)
    return jsonify({"message": "Files uploaded", "files": saved_files})

@app.route("/process", methods=["GET"])
def process_files():
    old_stdout = sys.stdout
    result = StringIO()
    sys.stdout = result
    fetch_and_print(UPLOAD_FOLDER, max_workers=3)
    sys.stdout = old_stdout
    return jsonify({"output": result.getvalue()})

if __name__ == "__main__":
    app.run(debug=True, port=5000)
